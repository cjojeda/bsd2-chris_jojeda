"""Launch behavior that protects the notebook's persistent business data."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import socket

import pytest


@pytest.fixture
def launcher():
    path = Path(__file__).resolve().parents[1] / 'run.py'
    spec = spec_from_file_location('sou_linda_launcher_tests', path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_self_test_leaves_real_business_untouched_and_cleans_temporary_database(launcher, monkeypatch, tmp_path):
    business = tmp_path / 'business'
    business.mkdir()
    database = business / 'sou-linda.sqlite3'
    database.write_bytes(b'existing business must never be opened by self-test')
    temporary_root = tmp_path / 'temporary'
    temporary_root.mkdir()
    monkeypatch.setenv('SADI_DATA_DIR', str(business))
    monkeypatch.setattr(launcher.tempfile, 'tempdir', str(temporary_root))

    assert launcher.main(['--self-test', '--data-dir', str(business)]) == 0

    assert database.read_bytes() == b'existing business must never be opened by self-test'
    assert list(business.iterdir()) == [database]
    assert list(temporary_root.iterdir()) == []


def test_instance_lock_excludes_second_launcher_then_releases(launcher, tmp_path):
    first = launcher.InstanceLock(tmp_path)
    try:
        with pytest.raises(RuntimeError, match='ya está abierto'):
            launcher.InstanceLock(tmp_path)
    finally:
        first.close()
        first.close()
    second = launcher.InstanceLock(tmp_path)
    second.close()


def test_failed_lock_acquisition_never_opens_or_backs_up_active_business(launcher, monkeypatch, tmp_path, capsys):
    distribution = Path(launcher.__file__).resolve().parents[1]
    if not (distribution / 'dist' / 'index.html').exists():
        pytest.skip('Requires the frontend distribution from npm run build')
    active = launcher.InstanceLock(tmp_path)
    def forbidden_database(*args, **kwargs):
        pytest.fail('A rejected second launcher must not touch the active database')
    monkeypatch.setattr(launcher, 'Database', forbidden_database)
    try:
        assert launcher.main(['--no-browser', '--data-dir', str(tmp_path)]) == 1
        assert 'ya está abierto' in capsys.readouterr().err
    finally:
        active.close()
    assert not (tmp_path / 'backups').exists()


def test_lan_detection_uses_only_local_private_ipv4_without_external_probe(launcher, monkeypatch):
    calls = []
    def records(host, port, *, family):
        calls.append((host, port, family))
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (address, 0)) for address in (
            '192.168.1.7', '10.0.0.5', '192.168.1.7', '127.0.0.1',
            '169.254.1.5', '0.0.0.0', '8.8.8.8')]
    monkeypatch.setattr(launcher.socket, 'gethostname', lambda: 'notebook')
    monkeypatch.setattr(launcher.socket, 'getaddrinfo', records)

    assert launcher.lan_addresses() == ['10.0.0.5', '192.168.1.7']
    assert calls == [('notebook', None, socket.AF_INET)]


def test_missing_network_interfaces_does_not_break_local_launch(launcher, monkeypatch):
    def unavailable(*args, **kwargs):
        raise OSError('network disconnected')
    monkeypatch.setattr(launcher.socket, 'getaddrinfo', unavailable)
    assert launcher.lan_addresses() == []
