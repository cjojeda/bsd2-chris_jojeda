"""SADI Desktop: local inventory, point of sale and financial management."""
__version__ = "0.3.0"
